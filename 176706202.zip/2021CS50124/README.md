
 # COL226-Assignment4 


_Kartik Arora         2021CS50124_


### Running instructions: ###
Clone the repository \
Then run the following to compile and run-
```
sml compiler.sml
interpret("<input_file>.rat", "<output_file>");
```
### Syntax Directed Grammar
```
start: blk                                    (blk)

blk: decseq comseq                            (Datatypes.Block(decseq,comseq))   

decseq: vardec procdec                        (Datatypes.Decseq(vardec, procdec))                

comseq: LBRACE commands RBRACE                (Datatypes.Comseq(commands))        

commands:                                     (Datatypes.comNone)
        | command SEMI commands               (Datatypes.Commands(command, commands))

command: assignmentcommand                    (Datatypes.assignCommand(assignmentcommand))
        | callcommand                         (Datatypes.callCommand(callcommand))
        | readcommand                         (Datatypes.readCommand(readcommand))
        | printcommand                        (Datatypes.printCommand(printcommand))
        | conditionalcommand                  (Datatypes.condCommand(conditionalcommand))
        | whilecommand                        (Datatypes.whileCommand(whilecommand))


vardec: ratvardec intvardec boolvardec        (Datatypes.Vardec(ratvardec, intvardec, boolvardec))       

ratvardec:                                    (Datatypes.ratvardecNone)
        | RATIONAL ident idents SEMI          (Datatypes.Ratvardec(ident, idents))

intvardec:                                    (Datatypes.intvardecNone)
        | INTEGER ident idents SEMI           (Datatypes.Intvardec(ident, idents))

boolvardec:                                   (Datatypes.boolvardecNone)
        | BOOL ident idents SEMI              (Datatypes.Boolvardec(ident, idents))


idents:                                       (Datatypes.identsNone)
        | COMMA ident idents                  (Datatypes.Idents(ident, idents))

procdec:                                      (Datatypes.procdecNone)
        | procdef SEMI procdec                (Datatypes.Procdec(procdef, procdec))

procdef: PROCEDURE ident blk                  (Datatypes.Procdef(ident, blk))

assignmentcommand: ident ASSIGN exp           (Datatypes.Assignmentcommand(ident, exp))

conditionalcommand: IF exp THEN comseq ELSE comseq FI        (Datatypes.Conditionalcommand(exp, comseq1, comseq2))

callcommand: CALL ident                       (Datatypes.Callcommand(ident))

readcommand: READ LPAREN ident RPAREN         (Datatypes.Readcommand(ident))

printcommand: PRINT LPAREN exp RPAREN         (Datatypes.Printcommand(exp))

whilecommand: WHILE exp DO comseq OD          (Datatypes.Whilecommand(exp, comseq))

ident: IDENT                                  (Datatypes.Ident(IDENT))

exp:  exp RATADD exp                          (Datatypes.Rataddexp(exp1,exp2))
        | exp RATSUB exp                      (Datatypes.Ratsubexp(exp1,exp2))
        | exp RATMUL exp                      (Datatypes.Ratmulexp(exp1,exp2))    
        | exp RATDIV exp                      (Datatypes.Ratdivexp(exp1,exp2))
        | RATIONAL_NUMBER                     (Datatypes.Ratexp(RATIONAL_NUMBER))
        | exp ADD exp                         (Datatypes.Intaddexp(exp1,exp2))  
        | exp SUB exp                         (Datatypes.Intsubexp(exp1,exp2)) 
        | exp MUL exp                         (Datatypes.Intmulexp(exp1,exp2)) 
        | exp DIV exp                         (Datatypes.Intdivexp(exp1,exp2)) 
        | exp MOD exp                         (Datatypes.Intmodexp(exp1,exp2)) 
        | INTEGER_NUMBER                      (Datatypes.Intexp(INTEGER_NUMBER)) 
        | NOT exp                             (Datatypes.Boolnotexp(exp))
        | exp AND exp                         (Datatypes.Boolandexp(exp1,exp2))
        | exp OR exp                          (Datatypes.Boolorexp(exp1,exp2))
        | exp LT exp                          (Datatypes.Boolltexp(exp1,exp2))
        | exp LTE exp                         (Datatypes.Boollteexp(exp1,exp2))
        | exp GT exp                          (Datatypes.Boolgtexp(exp1,exp2))
        | exp GTE exp                         (Datatypes.Boolgteexp(exp1,exp2))
        | exp EQ exp                          (Datatypes.Booleqexp(exp1,exp2))
        | exp NEQ exp                         (Datatypes.Boolneqexp(exp1,exp2))
        | LPAREN exp RPAREN                   (exp)
        | TRUE                                (Datatypes.Boolexp(TRUE))
        | FALSE                               (Datatypes.Boolexp(FALSE))
        | ident                               (Datatypes.Identexp(ident))
        | FROMDECIMAL LPAREN RATIONAL_NUMBER RPAREN                   (Datatypes.Ratexp(RATIONAL_NUMBER))
        | MAKERAT LPAREN exp COMMA exp RPAREN                         (Datatypes.MakeRat(exp1,exp2))
        | RAT LPAREN exp RPAREN                                       (Datatypes.toRat(exp))
 ```

### Files: ###
1. calc.grm
2. calc.grm.desc
3. calc.grm.sig
4. calc.grm.sml
5. calc.lex
6. calc.lex.sml
7. compiler.sml
8. datatypes.sml
9. evaluator.sml
10. glue.sml 
11. rational.sml
12. symbol_table.sml
13. type_checker.sml 

### Design Decisions: 
1. As in the previous assignment, I have not considered +3 as a valid integer, and +3.0 as a valid rational
2. Error handling has been done as seem fit. Extensive detailing has not been done as assumed valid/correct input

3. How I have implemented scoping 
- consider a global stack called staticstack (basically a list of symbol tables. And symbol table is a tuple of ((ident,type), (ident,val))). I know I could have made symbol table to just be a list of tuples (ident,val,type) but I didnt have time to do it again. No effect on output anyways 
- as I read variable declarations, I put them in the stack 
- when I go inside a procedure block, I make a new symbol table for that procedure and push it to the stack. as I exit a procedure block, I pop the latest symbol table (the one for that procedure) 
- If I encounter a procedure inside procedure, I push the symbol table for the new procedure onto the staticstack. 
- The value/type of ident at any point of time is correspoinding to its most recent occurence in the staticstack 



